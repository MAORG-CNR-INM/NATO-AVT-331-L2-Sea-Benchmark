import matplotlib.pyplot as plt
import numpy as np
import scipy.interpolate
import math
import os

from matplotlib import rc
rc('font', **{'family': 'sans-serif', 'sans-serif': ['Gill Sans MT'], 'weight' : 'bold','size':14})
rc('text', usetex=True)

plt.figure(figsize=(5,4),dpi=100)
HF = np.loadtxt('CS-DFN.txt')
StSr = np.loadtxt('MF-CS-DFN-StSr.txt')
StDr = np.loadtxt('MF-CS-DFN-StDr.txt')
DtSr = np.loadtxt('MF-CS-DFN-DtSr.txt')
DtDr = np.loadtxt('MF-CS-DFN-DtDr.txt')

plt.step(HF[:,0],HF[:,2]*100,color='k',linewidth=1,label='CS-DFN')
plt.step(StSr[:,0],StSr[:,2]*100,color='r',linestyle='-' ,linewidth=1,label='MF-CS-DFN (StSr)')
plt.step(StDr[:,0],StDr[:,2]*100,color='y',linestyle='--',linewidth=1,label='MF-CS-DFN (StDr)')
plt.step(DtSr[:,0],DtSr[:,2]*100,color='g',linestyle='-' ,linewidth=1,label='MF-CS-DFN (DtSr)')
plt.step(DtDr[:,0],DtDr[:,2]*100,color='b',linestyle='--',linewidth=1,label='MF-CS-DFN (DtDr)')

plt.xscale('log')
plt.xlim(1e-4,1e3)
#plt.ylim(36,50)

plt.xlabel('Normalized computational cost (NCC) [ -- ]')
plt.ylabel('$\Delta$Resistance\%')
plt.legend(loc='lower left',ncol=1,handletextpad=0.5,handlelength=1.,shadow=True,fancybox=True,fontsize=14)
#plt.legend(bbox_to_anchor=(-0.15, 1.03, 1.2, .102), loc=3,ncol=3, mode="expand", borderaxespad=0.,labelspacing=0.5)
plt.grid(color='k', linestyle='--', linewidth=0.1,alpha=0.25)
plt.subplots_adjust(left=0.14,right=0.95,top=0.95,bottom=0.14)#,wspace=0.25,hspace=0.2)
plt.savefig('opt_conv.pdf',transparent=True)
os.system("pdftoppm opt_conv.pdf opt_conv -png")


plt.figure(figsize=(5,4),dpi=100)
HF = np.loadtxt('CS-DFN.txt')
StSr = np.loadtxt('MF-CS-DFN-StSr.txt')
StDr = np.loadtxt('MF-CS-DFN-StDr.txt')
DtSr = np.loadtxt('MF-CS-DFN-DtSr.txt')
DtDr = np.loadtxt('MF-CS-DFN-DtDr.txt')

plt.step(HF[:,0],HF[:,2]*100,color='k',linewidth=1,label='CS-DFN')
plt.step(StSr[:,0],StSr[:,2]*100,color='r',linestyle='-' ,linewidth=1,label='MF-CS-DFN (StSr)')
plt.step(StDr[:,0],StDr[:,2]*100,color='y',linestyle='--',linewidth=1,label='MF-CS-DFN (StDr)')
plt.step(DtSr[:,0],DtSr[:,2]*100,color='g',linestyle='-' ,linewidth=1,label='MF-CS-DFN (DtSr)')
plt.step(DtDr[:,0],DtDr[:,2]*100,color='b',linestyle='--',linewidth=1,label='MF-CS-DFN (DtDr)')

#plt.xscale('log')
plt.xlim(100,700)
plt.ylim(-13,-8)

#plt.yticks([36,36.5,37,37.5,38],['$36.0$','$36.5$','$37.0$','$37.5$','$38.0$'])
plt.xlabel('Normalized computational cost (NCC) [ -- ]')
plt.ylabel('$\Delta$Resistance\%')
plt.legend(loc='upper right',ncol=1,handletextpad=0.5,handlelength=1.,shadow=True,fancybox=True,fontsize=14)
#plt.legend(bbox_to_anchor=(-0.15, 1.03, 1.2, .102), loc=3,ncol=3, mode="expand", borderaxespad=0.,labelspacing=0.5)
plt.grid(color='k', linestyle='--', linewidth=0.1,alpha=0.25)
plt.subplots_adjust(left=0.14,right=0.95,top=0.95,bottom=0.14)#,wspace=0.25,hspace=0.2)
plt.savefig('opt_conv_det.pdf',transparent=True)
os.system("pdftoppm opt_conv_det.pdf opt_conv_det -png")

plt.figure(figsize=(10,4),dpi=100)
HF = np.loadtxt('CS-DFN.txt')
DtSr = np.loadtxt('MF-CS-DFN-DtSr.txt')
MFva = np.loadtxt('MF-CS-DFN-DtSr_val.txt')

plt.step(HF[:,0],HF[:,2]*100,color='k',linewidth=1,label='CS-DFN')
plt.step(DtSr[:,0],DtSr[:,2]*100,color='g',linestyle='-',linewidth=1,label='MF-CS-DFN (DtSr)')
plt.scatter(MFva[:,0],(MFva[:,1]/MFva[0,1]-1)*100,color='g',marker='o',label='MF-CS-DFN (DtSr) validation')
plt.axvline(MFva[0,0],linewidth=1,color='r',linestyle='-.')
plt.axvline(MFva[1,0],linewidth=1,color='r',linestyle='-.')
plt.axvline(MFva[2,0],linewidth=1,color='r',linestyle='-.')
plt.axvline(MFva[3,0],linewidth=1,color='r',linestyle='-.')
plt.axvline(MFva[4,0],linewidth=1,color='r',linestyle='-.')
plt.axvline(MFva[5,0],linewidth=1,color='r',linestyle='-.')
plt.axvline(MFva[6,0],linewidth=1,color='r',linestyle='-.')
plt.text(0.4,-14,'G7')
plt.text(7.3,-14,'G6')
plt.text(13.4,-14,'G5')
plt.text(23.5,-14,'G4')
plt.text(43.,-14,'G3')
plt.text(85.,-14,'G2')
plt.text(300,-14,'G1')
plt.xscale('log')
plt.xlim(1e-2,1e3)
#plt.ylim(36,50)

#plt.yticks([36,36.5,37,37.5,38],['$36.0$','$36.5$','$37.0$','$37.5$','$38.0$'])
plt.xlabel('Normalized computational cost (NCC) [ -- ]')
plt.ylabel('$\Delta$Resistance\%')
plt.legend(loc='upper right',ncol=1,handletextpad=0.5,handlelength=1.,shadow=True,fancybox=True,fontsize=14)
#plt.legend(bbox_to_anchor=(-0.15, 1.03, 1.2, .102), loc=3,ncol=3, mode="expand", borderaxespad=0.,labelspacing=0.5)
plt.grid(color='k', linestyle='--', linewidth=0.1,alpha=0.25)
plt.subplots_adjust(left=0.08,right=0.95,top=0.95,bottom=0.14)#,wspace=0.25,hspace=0.2)
plt.savefig('opt_conv_val.pdf',transparent=True)
os.system("pdftoppm.exe opt_conv_val.pdf opt_conv_val -png")

